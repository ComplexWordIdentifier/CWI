1) cwi_testing.txt

The cwi_testing.txt file is the original testset for the SemEval 2016 Complex Word Identification task.
Each instance in the testset is distributed in the following format:

<sentence> <word> <index>

All components are separated by a tabulation marker.
The <sentence> component is a sentence extracted from a certain source.
The <word> component is a word in <sentence>.
The <index> component is the position of <word> in the tokens of <sentence>.