1) Introduction:
	This package contains the validation script for Task 11: Complex Word Identification of SemEval 2016.

2) Content:
	- README.txt: This file.
	- validate_system.py: System validation script in Python.

3) Running:
	The command line that runs the validation script is:
	
		python validate_system.py [-h] --gold GOLD --pred PRED
		
	If you use the "-h" option, you will get detailed instructions on the parameters required.
	The "--gold" parameter must be a dataset in the format provided by the task's organizers.
	The dataset can, but does not need to contain gold-standard labels.
	The "--pred" parameter must be the file containing the predicted labels.