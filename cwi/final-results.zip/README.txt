Content:
	This package contain the final results for the Complex Word Identification task of SemEval 2016.
	The files herein are:
		- README.txt: This file.
		- Statistics.txt: Contains updated overall statistics for the participant systems.
		- Results.xlsx: Contains the two final official rankings, which are based on the G-score and the F-score.
		- Friendly.txt: Contains the two final official rankings in LaTeX friendly format.
	
Guidelines:
	Baselines with the (TB) flag are Threshold-Based systems: the threshold that best separate complex from simple words is learned through brute-force given a certain feature.
	Threshold-Based systems with a "Prob:" prefix indicate that the feature used is the 3-gram language model probability over a certain corpus.
	Baselines with the (LB) flag are Lexicon-Based systems: if a word is in a given vocabulary, then it is simple, otherwise, it is complex.
	The "All Complex" and "All Simple" baselines predict that all words are complex and simple, respectively.
	Sense counts were extracted from WordNet.
	The Ogden's vocabulary was extracted from http://ogden.basic-english.org/words.html
	The Wikipedia and Simple Wikipedia corpora used are the document-aligned files made available by David Kauchak in http://www.cs.pomona.edu/~dkauchak/simplification/
	Please cite the approriate publications and authors in your system description papers.